ΠΑΙΧΝΙΔΙ "ΜΑΝΤΕΨΕ ΕΝΑΝ ΑΡΙΘΜΟ" ΜΕ ΤΗ ΧΡΗΣΗ FLASK

ΟΔΗΓΙΕΣ ΧΡΗΣΗΣ

1.Αποσυμπιέστε το ZIP σε έναν φάκελο
2.Πρέπει να έχετε την python εγκατεστημένη
3.Τρεξτε το αρχείο guessthenumber.py
4.Για να πάρετε τα απαραίτητα αρχεία, στο Terminal
    ΣΕ WINDOWS πληκτρολογήστε:
'Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser'
'venv\Scripts\Activate.ps1'

ΣΕ MACOS/LINUX:
'source venv/bin/activate'

3.Συνδεθείτε στην ιστοσελίδα
4.Ορίστε διάστημα για το παιχνίδι
5.Προσπαθήστε να μαντέψετε τον αριθμό