ΠΑΙΧΝΙΔΙ "ΜΑΝΤΕΨΕ ΕΝΑΝ ΑΡΙΘΜΟ" ΜΕ ΤΗ ΧΡΗΣΗ FLASK

ΟΔΗΓΙΕΣ ΧΡΗΣΗΣ

1.Αποσυμπιέστε το ZIP σε έναν φάκελο

2.Πρέπει να έχετε την python 3.3(ή άλλη νεότερη έκδοση) εγκατεστημένη

3.Για να πάρετε τα απαραίτητα αρχεία,ανοίξτε τον φάκελο που αποσυμπιέσατε το ZIP και στο Terminal πληκτρολογήστε: 

py –m pip install virtualenv

4.Πληκτρολογήστε:

python -m venv venv

5..ΣΕ WINDOWS πληκτρολογήστε:

.\venv\Scripts\Activate.ps1

ΣΕ MACOS/LINUX:
'source venv/bin/activate'

6.Αφού αρχίσει το virtual environment πληκτρολογήστε:

pip install -r requirements.txt

7.Τρεξτε το αρχείο guessthenumber.py

8.Συνδεθείτε στην ιστοσελίδα

9.Ορίστε διάστημα για το παιχνίδι

10.Προσπαθήστε να μαντέψετε τον αριθμό