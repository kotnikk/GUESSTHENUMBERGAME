from flask import Flask, request, render_template_string, redirect, url_for, session
import random
import datetime

#Στην αρχική εγκατάσταση του flask βοήθησε αρκετά το βίντεο https://www.youtube.com/watch?v=Z1RJmh_OqeA,
#κοίταξα ελάχιστα και το site (https://flask.palletsprojects.com/en/stable/tutorial/views/)

app =Flask(__name__)
app.secret_key='secretkey'

LOG_FILE="log.txt"

@app.route('/',methods=['GET','POST'])
def set_range():
    message=''
    if request.method=='POST':
        try:
            min_num=int(request.form['min_num'])
            max_num=int(request.form['max_num'])
            if min_num>=max_num:
                message='Το κάτω όριο πρέπει να είναι μικρότερο από το άνω όριο.'
                
            #Αρκετά χρήσιμα για τα sessions ήταν το site https://flask.palletsprojects.com/en/stable/tutorial/views/ 
            #και το βίντεο https://www.youtube.com/watch?v=iIhAfX4iek0&list=PLzMcBGfZo4-n4vJJybUVV3Un_NFS5EOgX&index=6
            else:
                session['min_num']=min_num
                session['max_num']=max_num
                session['number']=random.randint(min_num, max_num)
                session['attempts']=0
                session['time']=str(datetime.datetime.now())

                f=open(LOG_FILE,'a',encoding='utf-8')
                f.write(f"\n\nΝέο παιχνίδι ξεκίνησε στις:{session['time']}\nμε τυχαίο αριθμό:{session['number']}\n")
                f.close()
                return redirect(url_for('guess_number'))
        except ValueError:
            message='Παρακαλώ εισάγετε έγκυρους ακέραιους αριθμούς.'

    #Παρακάτω βοήθησαν αρκετά με την html τα βίντεο https://www.youtube.com/watch?v=QnDWIZuWYW0 https://www.youtube.com/watch?v=salY_Sm6mv4 και λίγο η ιστοσελίδα https://www.w3schools.com/html/html_basic.asp
    #και με την css https://www.w3schools.com/css/css_intro.asp https://www.youtube.com/watch?v=Z4pCqK-V_Wo και για μια ακόμη φορά το βίντεο https://www.youtube.com/watch?v=QnDWIZuWYW0
    #Επιπλέον εδώ ρώτησα το chatgpt για χρώματα που ταιριάζουν με το #474747 (σκούρο γκρί).
    return render_template_string('''
    <html>
    <head>
        <style>
            body{
                background-color:#474747;
                color: #B7410E;
                display:flex;
                flex-direction:column;
                justify-content:center;
                align-items:center;
                height:100vh;
                margin:0;
                font-family:Arial,sans-serif;
            }
            h1{
                margin-bottom:20px;
            }
            form{
                display:flex;
                flex-direction:column;
                gap:10px;
                align-items:center;
            }
            input[type="number"]{
                padding:8px;
                font-size:16px;
                border-radius:4px;
                border:none;
                width:150px;
                text-align:center;
                background-color:#D2B48C;
                color:black;
            }
            input[type="submit"]{
                padding:8px 16px;
                font-size:16px;
                border-radius:4px;
                border:none;
                cursor:pointer;
                background-color:#E97451 ;
                color:black;
            }
            p{
                margin-top:20px;
                font-size:18px;
                color: #e74c3c;
            }
        </style>
    </head>
    <body>
        <h1>Ορίστε το διάστημα μαντεψιάς</h1>
        <form method="POST">
            <input type="number" name="max_num" placeholder="Άνω όριο" required autofocus>
            <input type="number" name="min_num" placeholder="Κάτω όριο" required>
            <input type="submit" value="Έναρξη">
        </form>
        <p>{{message}}</p>
    </body>
    </html>
    ''',message=message)


@app.route('/guess',methods=['GET', 'POST'])
#παρακάτω βοήθησε η ιστοσελίδα https://flask.palletsprojects.com/en/stable/tutorial/views/
#αλλά και οι δύο παρόμοιες εφαρμογές από τις οποίες κοίταξα τον κώδικα
#https://github.com/barbaracalderon/flask-higher-lower (παρόμοια ιδέα)
#https://github.com/Lkikui/NumberGame-Flask για templates
def guess_number():
    if 'number' not in session or 'min_num' not in session or 'max_num' not in session:
        return redirect(url_for('set_range'))

    message=''
    mcolor='#B7410E'
    min_num=session['min_num']
    max_num=session['max_num']
    rnumber=session['number']
    finished=False

    if request.method=='POST':
        try:
            guess=int(request.form['guess'])
            if guess<min_num or guess>max_num:
                message = f'Παρακαλώ μάντεψε έναν αριθμό μέσα στο εύρος {min_num} έως {max_num}.'
                mcolor='#e74c3c'
            else:
                session['attempts']+=1
                number=session['number']

                if guess<number:
                    message='Ο αριθμός είναι μεγαλύτερος!'
                    mcolor='#d4a017'
                    result='Ο αριθμός είναι μεγαλύτερος'
                elif guess>number:
                    message='Ο αριθμός είναι μικρότερος!'
                    mcolor='#d4a017'
                    result='Ο αριθμός είναι μικρότερος'
                else:
                    message=f'Σωστά! Μάντεψες τον αριθμό {number} σε {session["attempts"]} προσπάθειες!'
                    mcolor='#6b8e23'
                    result='Μάντεψες τον αριθμό'
                    finished=True

                f=open(LOG_FILE,'a',encoding='utf-8')
                f.write(f"Αριθμός που μάντεψε ο χρήστης: {guess}, Απάντηση προγράμματος: {result}\n")
                f.close()

                if finished==True:
                    session.pop('number')
                    session.pop('attempts')
                    session.pop('min_num')
                    session.pop('max_num')

        except ValueError:
            message='Παρακαλώ εισάγετε έναν έγκυρο ακέραιο αριθμό.'
            mcolor='#e74c3c'
    #κάτω από εδώ βοήθησε το βίντεο 
    #https://www.youtube.com/watch?v=UIJKdCIEXUQ&t=316s
    #και λίγο το αρχείο templates του zip στο github:https://github.com/Lkikui/NumberGame-Flask
    #υπήρχε πάλι η βοήθεια για την hmtl και τη css από τις πηγές που έχω προσθέσει στις γραμμές 37,38,39
    return render_template_string('''
    <html>
    <head>
        <style>
            body {
                background-color: #474747;
                color:#B7410E;
                display:flex;
                flex-direction:column;
                justify-content:center;
                align-items:center;
                height:100vh;
                margin:0;
                font-family:Arial,sans-serif;
            }
            h1 {
                margin-bottom:20px;
            }
            form {
                display:flex;
                gap:10px;
            }
            input[type="number"]{
                padding:8px;
                font-size:16px;
                border-radius:4px;
                border:none;
                width:200px;
                text-align:center;
                background-color:#D2B48C;
                color:black;
            }
            input[type="submit"] {
                padding:8px 16px;
                font-size:16px;
                border-radius:4px;
                border:none;
                cursor:pointer;
                background-color:#E97451;
                color:black;
            }
            p{
                margin-top:20px;
                font-size:18px;
            }
        </style>
    </head>

    <body>
        <h1>Μάντεψε έναν αριθμό από {{min_num}} έως {{max_num}}</h1>
        {% if finished==False %}
        <form method="POST">
            <input type="number" name="guess" autofocus required>
            <input type="submit" value="Μάντεψε!">
        </form>
        {% endif %}
        <p style="color:{{mcolor}};">{{message}}</p>
        {% if finished==True %}
            <a href="{{url_for('set_range')}}"style="color:#E97451;font-size:18px;">Ξεκίνα νέο παιχνίδι</a>
        {% endif %}
    </body>
    </html>
    ''',message=message,min_num=min_num,max_num=max_num,finished=finished,mcolor=mcolor)


if __name__=='__main__':
    app.run(debug=True)
